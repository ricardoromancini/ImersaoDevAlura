var valorDolarTexto = prompt("Qual o valor em Dólar você quer converter?")
var valorDolar = parseFloat(valorDolarTexto)

var valorReal = valorDolar * 5.50
var valorRealFixo = valorReal.toFixed(2)

alert(valorRealFixo)
